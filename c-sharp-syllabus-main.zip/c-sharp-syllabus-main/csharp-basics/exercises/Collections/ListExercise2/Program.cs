﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListExercise2
{
    class Program
    {
        private static void Main(string[] args)
        {
            //TODO: Write a C# program to iterate through all elements in a list.

            var colors = new List<string>();
            colors.Add("Red");
            colors.Add("Green");
            colors.Add("Orange");
            colors.Add("White");
            colors.Add("Black");

            /*
            fixme
            for (...) 
            {
              Console.WriteLine(element);
            }
            */
        }
    }
}
