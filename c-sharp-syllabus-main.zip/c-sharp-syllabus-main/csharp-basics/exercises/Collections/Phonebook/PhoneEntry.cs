namespace PhoneBook
{
    public class PhoneEntry
    {
        public string name;
        public string number;
    }
}