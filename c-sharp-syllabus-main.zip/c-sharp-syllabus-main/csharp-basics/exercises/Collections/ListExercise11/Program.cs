﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListExercise11
{
    class Program
    {
        static void Main(string[] args)
        {
            //TODO: Create an List with string elements

            //TODO: Add 10 values to list

            //TODO: Add new value at 5th position

            //TODO: Change value at last position (Calculate last position programmatically)

            //TODO: Sort your list in alphabetical order

            //TODO: Check if your list contains "Foobar" element

            //TODO: Print each element of list using loop
        }
    }
}
