# Mini Projects

## Picture Viewer

Follow the instructions [here](https://docs.microsoft.com/en-us/visualstudio/ide/tutorial-windows-forms-picture-viewer-layout?view=vs-2022).

## Math Quiz

Follow the instructions [here](https://github.com/MicrosoftDocs/visualstudio-docs/blob/master/docs/ide/tutorial-2-create-a-timed-math-quiz.md).

## Memory Game

Follow the instructions [here](https://github.com/MicrosoftDocs/visualstudio-docs/blob/master/docs/ide/tutorial-3-create-a-matching-game.md).

## Minesweeper

Follow the instructions [here](./Minesweeper).

