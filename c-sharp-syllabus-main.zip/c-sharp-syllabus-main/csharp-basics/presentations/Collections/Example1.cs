//create array bigger than needed
Book[] books = new Book[10];
int nextIndex = 0;
books[nextIndex] = b;

//track indexes
nextIndex = nextIndex + 1;