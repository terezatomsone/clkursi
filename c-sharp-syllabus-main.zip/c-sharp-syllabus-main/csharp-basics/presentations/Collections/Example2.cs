Book[] books = new Book[10];
int nextIndex = 0;
books[nextIndex] = b;
nextIndex += 1;

List<Book> books
        = new List<Book>();
books.add(b);