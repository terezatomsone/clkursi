int number = 10;

if (number > 0)
{
    Console.WriteLine("Number is positive.");
}
else
{
    Console.WriteLine("Number is not positive.");
}

Console.WriteLine("This statement is always executed.");