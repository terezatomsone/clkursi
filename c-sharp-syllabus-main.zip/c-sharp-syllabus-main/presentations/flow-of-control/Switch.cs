switch (number)
{
    case 1:
        Console.WriteLine("Number is one!");
        break;
    case 2:
        Console.WriteLine("Number is two!");
        break;
    case 10:
        Console.WriteLine("Number is ten!");
        break;
    default:
        Console.WriteLine("I don't know this number.");
        break;
}