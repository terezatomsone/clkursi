//must have an initial size defined
int[] myArray = new int[7];

myArray[0] = 7;
myArray[1] = 3;
myArray[2] = 9;
myArray[3] = 8;
myArray[4] = 4;
myArray[5] = 8;
myArray[6] = 6;

Console.WriteLine(myArray[0]); //7
Console.WriteLine(myArray[3]); //8