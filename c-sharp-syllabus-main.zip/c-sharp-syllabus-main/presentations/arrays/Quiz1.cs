byte[] array = { 12, 34, 9, 0, -62, 88 };
Console.WriteLine(array.Length);
// What will be the output?
// 1. 7
// 2. 6
// 3. 5
// 4. compilation error
// 5. runtime error