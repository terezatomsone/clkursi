//preincrement
int x = 1;
int y = ++x;
Console.WriteLine(y);
// output 2
Console.WriteLine(x);
// output 2

//postincrement
int w = 1;
int z = w++;
Console.WriteLine(z);
// output 1
Console.WriteLine(w);
// output 2