Console.WriteLine(
                1/2 
                - 1/10 
                - 1/10 
                - 1/10 
                - 1/10 
                - 1/10
                );
// output?