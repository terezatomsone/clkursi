// C# program to demonstrate the 
// Explicit Type Conversion 
using System; 
namespace Casting{ 

    class GFG { 

            // Main Method 
            public static void Main(String []args) 
            { 
                double d = 765.12; 

                // Explicit Type Casting 
                int i = (int)d; 

                // Display Result 
                Console.WriteLine("Value of i is " +i); //???
            } 
    } 
} 
