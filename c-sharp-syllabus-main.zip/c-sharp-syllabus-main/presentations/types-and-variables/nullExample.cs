static void Main(string[] args)
{
    //wont even compile
    int integer = null;
    Console.WriteLine(integer.toString());
}