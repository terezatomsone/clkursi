String example1 = "CODELEX";
char[] chars = { 'C', 'O', 'D', 'E', 'L', 'E', 'X' };
String example2 = new String(chars);