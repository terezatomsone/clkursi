String stringType = "String";
int otherType = 5;
String example = "A " + stringType
        + " can be concatenated"
        + " with other types also"
        + otherType;
Console.WriteLine(example);