int x = 1;

while (x <= 4)
{
    Console.WriteLine("Value of x: " + x);
    x++;
}