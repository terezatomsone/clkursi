public abstract class Bird : Animal {
    private string species;

    public void layEgg() {
        //complex egg laying process...
    }

    public abstract bool canFly();
}