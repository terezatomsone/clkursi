public interface ITaxable
{
    double tax { get; }
    double calculateTax();
}