class Quiz {
    public static void main(String[] args) {
        Eagle var1 = new Animal();
        Animal var2 = new Eagle();
        Animal var3 = new Animal();
        // Which example wont compile and why?
        // 1. var1, var2 
        // 2. var2
        // 3. var1, var3 
        // 4. all of them 
    }
}